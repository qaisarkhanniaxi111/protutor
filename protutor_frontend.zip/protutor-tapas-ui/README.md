# onlinetutor
This project is to develop a Learning Management System (LMS) website that enables white labeling and customization through an admin-controlled CMS. It facilitates tutors worldwide to register, create, and market their courses. The platform also allows students to view, purchase, and access these courses, including an option for a free trial.
