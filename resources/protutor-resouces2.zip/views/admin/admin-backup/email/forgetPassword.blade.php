<h1>OTP Verification</h1>

Your One Time Password is<span>{{$token}}</span> - ProTotur.
