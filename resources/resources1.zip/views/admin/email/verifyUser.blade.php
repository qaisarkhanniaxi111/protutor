<h1>Your Email Verification</h1>

You can verify Your email from bellow link:
<a href="{{ url('/verify-user/'.$remember_token) }}">Verify</a>
