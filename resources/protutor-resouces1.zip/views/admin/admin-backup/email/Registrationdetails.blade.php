<h1>Your Registration Details</h1>

Your Registration Details bellow:
<p>Email: {{$all_data['email']}}</p>
<p>Password: {{$all_data['password']}}</p>

