<!-- Footer -->
<footer class="site-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-4">
                <p>+00 000 000 000 <span>support@tutorsonline.com</span></p>
            </div>
            <div class="col-xl-4">
                <p class="text-center">All Rights Reserved by Tutors Online</p>
            </div>
            <div class="col-xl-4">
                <p class="text-end">Designed & Developed With Love by Coding Pro</p>
            </div>
        </div>
    </div>
</footer>
<!-- Footer -->

</div>


<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/tilt.js@1.2.1/dest/tilt.jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
<script src="assets/dashboard_assets/js/custom.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>


</body>

</html>
